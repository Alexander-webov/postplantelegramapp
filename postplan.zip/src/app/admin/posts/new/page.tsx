import { BlogPostEditor } from '@/components/admin/blog-post-editor';

export default function NewBlogPostPage() {
  return <BlogPostEditor />;
}
